import java.util.HashMap;
import java.util.Map;

public class highestfre {
    public static void main(String[] args){
        int[] arr={10,20,30,20,10,20};
        Map<Integer,Integer>map=new HashMap<>();
        for(int n:arr){
            map.put(n,map.getOrDefault(n,0)+1);
        }
        int maxEle=arr[0];
        int count=0;
        for(Map.Entry<Integer,Integer>entry:map.entrySet()){
            if(entry.getValue()>count){
                maxEle=entry.getKey();
                count=entry.getValue();
            }
        }
        System.out.println("Key: "+maxEle+" value: "+count);
    }
}
