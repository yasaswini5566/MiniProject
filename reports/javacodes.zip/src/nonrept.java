import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class nonrept {
    public static void main(String[] args){
        int[] arr={10,20,30,40,10};
        Map<Integer,Integer>map=new LinkedHashMap<>();
        for(int n:arr){
            map.put(n,map.getOrDefault(n,0)+1);
        }
        for(Map.Entry<Integer,Integer>entry:map.entrySet()){
            if(entry.getValue()==1){
                System.out.println("first non repeating: "+entry.getKey());
                break;
            }
        }
    }
}
