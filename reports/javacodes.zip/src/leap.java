public class leap {
    public static void main(String[] args){
        int y=2024;
        System.out.println((y%4==0 && y%100!=0)||y%400==0);
    }
}
