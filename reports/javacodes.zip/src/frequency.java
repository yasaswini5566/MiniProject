import java.util.*;
public class frequency {
    public static void main(String[] args){
        int[] arr={10,20,30,20,10};
        Map<Integer,Integer>map=new HashMap<>();
        for(int c:arr){
            map.put(c,map.getOrDefault(c,0)+1);
        }
        System.out.println(map);
        for(Map.Entry<Integer,Integer>entry:map.entrySet()){
            if(entry.getValue()==1){
                System.out.println(entry.getKey()+" = "+entry.getValue()+" times");
            }
            else{
                System.out.println(entry.getKey()+" = "+entry.getValue()+" times");
            }
        }
    }
}