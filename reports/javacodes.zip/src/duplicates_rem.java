import java.util.*;

public class duplicates_rem {
    public static void main(String[] args){
        int[] arr={10,20,10,30};
        Set<Integer> seen=new HashSet<>();
        Set<Integer>dup=new HashSet<>();
        for(int num:arr){
            if(!seen.add(num)){
                dup.add(num);
            }
        }
        System.out.println("duplicates "+dup);
        System.out.println("removed "+seen);
    }
}
