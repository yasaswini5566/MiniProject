import java.util.HashSet;
import java.util.Set;

public class firstrept {
    public static  void main(String[] args){
        int[] arr={10,20,30,20,10};
        Set<Integer>s=new HashSet<>();
        for(int n:arr){
            if(!s.add(n)){
                System.out.println("first repeat: "+n);
                break;
            }
        }
        }
}
