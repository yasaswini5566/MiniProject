import java.util.*;
public class dup_linked {
    public static void main(String[] args){
        int[] arr={10,20,10,20,30,40};
        Set<Integer>a=new LinkedHashSet<>();
        Set<Integer>d=new LinkedHashSet<>();
        for(int c:arr){
            if(!a.add(c)){
                d.add(c);
            }
        }
        System.out.println("duplicates : "+d);
        System.out.println("unique : "+a);
    }
}
