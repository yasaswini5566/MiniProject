import java.util.*;
public class dup_hashset {
    public static void main(String[] args){
        int[] arr={10,20,10,20,30,40};
        Set<Integer>a=new HashSet<>();
        Set<Integer>d=new HashSet<>();
        for(int c:arr){
            if(!a.add(c)){
                d.add(c);
            }
        }
        System.out.println("duplicates : "+d);
        System.out.println("unique : "+a);
    }
}
