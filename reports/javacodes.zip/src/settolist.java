import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class settolist {
    public static void main(String[] args){
        Set<Integer>set=new HashSet<>();
        set.add(10);
        set.add(20);
        List<Integer>l=new ArrayList<>(set);
        System.out.println(l);
    }
}
