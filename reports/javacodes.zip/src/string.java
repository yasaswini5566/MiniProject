public class string {
    public static void main(String[] args){
        String s=" Yasaswini ";
        char c='A';
        String u=s.substring(0,4).toUpperCase();
        String l=s.substring(4).toLowerCase();
        System.out.println(u+l);
        System.out.println(s.replace(" ",""));
        System.out.println((int)c);
    }
}
