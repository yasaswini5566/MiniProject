public class min_max_secolrg {
    public static void main(String[] args){
        int a=10,b=20,c=5;
        int max=Math.max(a,Math.max(b,c));
        int min=Math.min(a,Math.min(b,c));
        System.out.println(min+" "+max);
        int[] arr={30,20,40,10};
        java.util.Arrays.sort(arr);
        System.out.println(arr[arr.length-2]);
    }
}
