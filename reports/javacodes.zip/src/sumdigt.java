public class sumdigt {
    public static void main(String[] args) {
        String s="Yas23as23wini";
        String num=s.replaceAll("[^0-9]+"," ").trim();
        String[] parts=num.split(" ");
        int sum=0;
        for(String n:parts){
            sum+=Integer.parseInt(n);
        }
        System.out.println(sum);
    }
}