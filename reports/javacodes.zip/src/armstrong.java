public class armstrong {
    public static void main(String[] args){
        int n=153,sum=0,temp=n;
        String s=Integer.toString(n);
        while(temp!=0){
            int d=temp%10;
            sum+=Math.pow(d,s.length());
            temp/=10;
        }
        System.out.println(sum==n);
    }
}
