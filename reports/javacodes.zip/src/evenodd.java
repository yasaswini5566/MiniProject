import java.util.Scanner;
public class evenodd {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        if(n%2==0 && n!=0){
            System.out.println("Even number");
        }
        else if(n<=0){
            System.out.println("Neither even nor odd");
        }
        else{
            System.out.println("Odd number");
        }
    }
}
