public class eachcharrev {
    public static void main(String[] args){
        String s="hello world";
        String[] words=s.split(" ");
        String r="";
        for(String word:words){
            String rev="";
            for(int i=word.length()-1;i>=0;i--){
                rev+=word.charAt(i);
            }
            r+=rev+" ";
        }
        System.out.println(r.trim());
    }
}
