public class volconst {
    public static void main(String[] args){
        String s="automation";
        int vol=0,con=0;
        s=s.toLowerCase();
        for(char c:s.toCharArray()){
            if(c>='a' && c<='z'){
                if(c=='a'||c=='e'||c=='o'||c=='u'||c=='i'){
                    vol+=1;
                }
                else{
                    con+=1;}
            }
        }
        System.out.println("vowels: "+vol+" consonants: "+con);
    }
}
