import java.util.Scanner;

public class palindromenum {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int rev=0,temp=n;
        while(temp!=0){
            rev=rev*10+temp%10;
            temp/=10;
        }
        System.out.println(n==rev);
    }
}
