public class digitsumstr {
    public static void main(String[] args) {
        String s="Yas23as23wini";
        int sum=0;
        for(char c:s.toCharArray()){
            if(Character.isDigit(c)){
                sum=sum+c- '0';
            }
        }
        System.out.println(sum);
    }
}
