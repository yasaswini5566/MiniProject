import java.util.Scanner;

public class palindromestr {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        s=s.toLowerCase();
        String rev=new StringBuilder(s).reverse().toString();
        if(s.equals(rev)){
            System.out.println("Palindrome");
        }
        else{
            System.out.println("Not");
        }
    }
}
