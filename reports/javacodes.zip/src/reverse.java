import java.util.Scanner;

public class reverse {
    public static void main(String[] args){
        String s="java",rev="";
        System.out.println(new StringBuilder(s).reverse());
    }
}
